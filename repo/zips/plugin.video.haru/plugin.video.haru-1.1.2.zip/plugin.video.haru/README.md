# plugin.video.haru

a basic kodi anime addon

[https://pikdum.github.io/repository.pikdum/](https://pikdum.github.io/repository.pikdum/)

## design goals

* correct
* fast
* simple

## requirements

* Kodi 19+
* ResolveURL

## features

* anime list
* airing anime list
* watched indicators
* batch support

## roadmap

* better logo
* better anime art
* mal/kitsu/etc support
* nyaa search
