![Version](https://img.shields.io/github/v/tag/pikdum/plugin.video.haru?label=version&logo=github)
![License](https://img.shields.io/github/license/pikdum/plugin.video.haru)

# haru

<img src="icon.png" width="270" align="right" alt="haru">

a basic kodi anime addon

[https://pikdum.github.io/repository.pikdum/](https://pikdum.github.io/repository.pikdum/)

## design goals

- correct
- fast
- simple

## requirements

- kodi 19+
- ~~debrid account~~
  - debrid is optional if using [torrest](https://github.com/i96751414/plugin.video.torrest)

## features

- anime list
- airing anime list
- watched indicators
- batch support
- watch history
- nyaa search
- sukebei search
- resolveurl (debrid) support
- torrest (no debrid) support

## roadmap

- better anime art
