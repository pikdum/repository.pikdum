# Changelog

## [1.25.0](https://github.com/pikdum/plugin.video.haru/compare/v1.24.4...v1.25.0) (2026-04-08)


### Features

* history overhaul ([30b37cf](https://github.com/pikdum/plugin.video.haru/commit/30b37cf4faa9bab20994374ab8e20ddfa5dfa1eb))
* **settings:** add clear cache action ([661fadd](https://github.com/pikdum/plugin.video.haru/commit/661fadd9ee5a10ca5f66bfe832998e804874d0d5))


### Performance Improvements

* **subsplease:** cache latest episode for unfinished checks ([a327202](https://github.com/pikdum/plugin.video.haru/commit/a327202cd02145bfa1a4b489f8fd879d6b1f21de))
* **subsplease:** cache show ids for unfinished checks ([a585b37](https://github.com/pikdum/plugin.video.haru/commit/a585b37e002f173e0a51cb9d137f70484ba3e50e))

## [1.24.4](https://github.com/pikdum/plugin.video.haru/compare/v1.24.3...v1.24.4) (2026-04-04)


### Bug Fixes

* **subsplease:** gray out not yet available shows ([38e7ea4](https://github.com/pikdum/plugin.video.haru/commit/38e7ea4807f8098165be5f656737811d052d1505))

## [1.24.3](https://github.com/pikdum/plugin.video.haru/compare/v1.24.2...v1.24.3) (2026-04-04)


### Bug Fixes

* **subsplease:** don't error on empty shows ([ff52762](https://github.com/pikdum/plugin.video.haru/commit/ff52762850797b626452b24dc853b7b1cc775464))

## [1.24.2](https://github.com/pikdum/plugin.video.haru/compare/v1.24.1...v1.24.2) (2026-04-03)


### Bug Fixes

* do not set watched on errors ([e681f57](https://github.com/pikdum/plugin.video.haru/commit/e681f5787c8f49126294f2df729675af35f62f84))

## [1.24.1](https://github.com/pikdum/plugin.video.haru/compare/v1.24.0...v1.24.1) (2026-04-03)


### Bug Fixes

* more specific resolve errors ([9de797f](https://github.com/pikdum/plugin.video.haru/commit/9de797f192f6cd384ef4ff266e8406a6af89af7f))

## [1.24.0](https://github.com/pikdum/plugin.video.haru/compare/v1.23.2...v1.24.0) (2026-01-18)


### Features

* add cache busting to artwork ([16ee46c](https://github.com/pikdum/plugin.video.haru/commit/16ee46c5813e7245df68e0af2a5f773f6e7b00fb))


### Bug Fixes

* **subsplease:** ignore v2 in unfinished checks ([fae1201](https://github.com/pikdum/plugin.video.haru/commit/fae1201f4de75dfcc6d7b397b20ef8d21a5a489e))

## [1.23.2](https://github.com/pikdum/plugin.video.haru/compare/v1.23.1...v1.23.2) (2026-01-16)


### Bug Fixes

* handle special characters in filenames ([2b8b8f1](https://github.com/pikdum/plugin.video.haru/commit/2b8b8f19bf49801839ada84e3150f415da8ead7b))

## [1.23.1](https://github.com/pikdum/plugin.video.haru/compare/v1.23.0...v1.23.1) (2025-09-22)


### Bug Fixes

* **subsplease:** error when checking unfinished ([c9de528](https://github.com/pikdum/plugin.video.haru/commit/c9de528c56149109311bddea55e62d0daf0c5dfd))

## [1.23.0](https://github.com/pikdum/plugin.video.haru/compare/v1.22.0...v1.23.0) (2025-05-21)


### Features

* add 'Play' option to context menus ([#61](https://github.com/pikdum/plugin.video.haru/issues/61)) ([1b69cb7](https://github.com/pikdum/plugin.video.haru/commit/1b69cb793e936684589e0985bd1c66af713d3cef))

## [1.22.0](https://github.com/pikdum/plugin.video.haru/compare/v1.21.2...v1.22.0) (2024-09-06)


### Features

* update mona url ([1fcaf5f](https://github.com/pikdum/plugin.video.haru/commit/1fcaf5fd845242491679d2d11678936c594dbf80))

## [1.21.2](https://github.com/pikdum/plugin.video.haru/compare/v1.21.1...v1.21.2) (2024-07-26)


### Bug Fixes

* handle occasional string indices error ([d83e660](https://github.com/pikdum/plugin.video.haru/commit/d83e660cfb3ccb5b256c20ebbffa285c1cf25fec))

## [1.21.1](https://github.com/pikdum/plugin.video.haru/compare/v1.21.0...v1.21.1) (2024-05-26)


### Bug Fixes

* add debug logging ([3528c50](https://github.com/pikdum/plugin.video.haru/commit/3528c50e87804eb3350afe06c542893ec931720d))
* log the engine too ([3b447eb](https://github.com/pikdum/plugin.video.haru/commit/3b447eb119396b5172c480aef3b80cf919aec824))

## [1.21.0](https://github.com/pikdum/plugin.video.haru/compare/v1.20.1...v1.21.0) (2024-05-12)


### Features

* **subsplease:** add search ([75dda36](https://github.com/pikdum/plugin.video.haru/commit/75dda362a5f7e2f1ea924177ce3ce3b03bfcfdee))

## [1.20.1](https://github.com/pikdum/plugin.video.haru/compare/v1.20.0...v1.20.1) (2024-05-04)


### Bug Fixes

* addon news generation ([3481557](https://github.com/pikdum/plugin.video.haru/commit/3481557a07d321204ba239fa843789738befd8cc))
* revert "feat: add requests cache" ([1fd6022](https://github.com/pikdum/plugin.video.haru/commit/1fd6022d76adf63248dd639f90992fffc00b83ea))

## [1.20.0](https://github.com/pikdum/plugin.video.haru/compare/v1.19.0...v1.20.0) (2024-05-04)


### Features

* switch to new art endpoints ([3977257](https://github.com/pikdum/plugin.video.haru/commit/3977257e9f3e86b9fae6bd0d8279c9f648efc37b))

## [1.19.0](https://github.com/pikdum/plugin.video.haru/compare/v1.18.0...v1.19.0) (2024-05-03)


### Features

* add requests cache ([29400ae](https://github.com/pikdum/plugin.video.haru/commit/29400ae11d4282d926cc027d68d9ae3e3d44f49f))

## [1.18.0](https://github.com/pikdum/plugin.video.haru/compare/v1.17.1...v1.18.0) (2024-04-28)


### Features

* **subsplease:** airing unfinished ([d73d0f7](https://github.com/pikdum/plugin.video.haru/commit/d73d0f72d889da0343570eb9a4b142a9926511e6))


### Bug Fixes

* don't show disabled addon settings ([b229ea9](https://github.com/pikdum/plugin.video.haru/commit/b229ea95a2cc656a7427a54df6fe44ba5f488730))
* **subsplease:** color unfinished titles ([1b18401](https://github.com/pikdum/plugin.video.haru/commit/1b18401d2a37cc0ba8359aee0a044995b80a42f7))

## [1.17.1](https://github.com/pikdum/plugin.video.haru/compare/v1.17.0...v1.17.1) (2024-04-24)


### Bug Fixes

* **subsplease:** revert image endpoints ([e44cfe2](https://github.com/pikdum/plugin.video.haru/commit/e44cfe209baf89fdba791d9742dadd787c8a839d))

## [1.17.0](https://github.com/pikdum/plugin.video.haru/compare/v1.16.0...v1.17.0) (2024-04-24)


### Features

* new icons & more ([#49](https://github.com/pikdum/plugin.video.haru/issues/49)) ([ef97264](https://github.com/pikdum/plugin.video.haru/commit/ef97264400479408855e5093dcdcd2f0278ad4db))

## [1.16.0](https://github.com/pikdum/plugin.video.haru/compare/v1.15.0...v1.16.0) (2024-04-21)


### Features

* **sukebei:** add latest and popular ([d631ad6](https://github.com/pikdum/plugin.video.haru/commit/d631ad66d60073a99e10b1e6615168153847d17d))

## [1.15.0](https://github.com/pikdum/plugin.video.haru/compare/v1.14.0...v1.15.0) (2024-04-20)


### Features

* **nyaa:** more consistent torrent art ([71e2738](https://github.com/pikdum/plugin.video.haru/commit/71e2738f986a19ef1f428759962bfcd076c96e0e))
* **sukebei:** use thumbnails from description ([5cab33b](https://github.com/pikdum/plugin.video.haru/commit/5cab33bf1cb4b04c1186e575a5cc345238d9b025))


### Bug Fixes

* **subsplease:** unfinished error if no episodes ([af1298b](https://github.com/pikdum/plugin.video.haru/commit/af1298b3cefae0590d1aa34d6be1264d5cec1175))
* **subsplease:** unfinished progress bar ([6d87f6d](https://github.com/pikdum/plugin.video.haru/commit/6d87f6d50ff045cd6241ca42a4556884de5d48d7))

## [1.14.0](https://github.com/pikdum/plugin.video.haru/compare/v1.13.0...v1.14.0) (2024-04-02)


### Features

* add option to clear thumbnail cache ([a8b57e0](https://github.com/pikdum/plugin.video.haru/commit/a8b57e079538043415ad6e3efd57077280892fa4))

## [1.13.0](https://github.com/pikdum/plugin.video.haru/compare/v1.12.0...v1.13.0) (2024-03-27)


### Features

* add elementum support ([#44](https://github.com/pikdum/plugin.video.haru/issues/44)) ([dda79a1](https://github.com/pikdum/plugin.video.haru/commit/dda79a1ead2e536988da19f8da30747e62f3b974))

## [1.12.0](https://github.com/pikdum/plugin.video.haru/compare/v1.11.0...v1.12.0) (2024-01-24)


### Features

* **subsplease:** look up unfinished shows ([f6edd6f](https://github.com/pikdum/plugin.video.haru/commit/f6edd6f24e630c581b6feff3a76818762644c0bd))

## [1.11.0](https://github.com/pikdum/plugin.video.haru/compare/v1.10.0...v1.11.0) (2023-10-05)


### Features

* **nyaa:** add latest + popular links ([ce086d1](https://github.com/pikdum/plugin.video.haru/commit/ce086d1b91f0999e20c9507d2f84bae2834b59bb))
* **nyaa:** add search sorting options ([cc104b3](https://github.com/pikdum/plugin.video.haru/commit/cc104b382d25f16c48ca890e9819b602d6ea8944))
* **nyaa:** allow search results in skin widgets ([d2132a8](https://github.com/pikdum/plugin.video.haru/commit/d2132a8548b5e75fe8eb34c04c96b0179db66b56))

## [1.10.0](https://github.com/pikdum/plugin.video.haru/compare/v1.9.0...v1.10.0) (2023-09-16)


### Features

* better poster + fanart ([#37](https://github.com/pikdum/plugin.video.haru/issues/37)) ([6177371](https://github.com/pikdum/plugin.video.haru/commit/617737158ce9bd9d8695db31bc559c0bb76f27f4))

## [1.9.0](https://github.com/pikdum/plugin.video.haru/compare/v1.8.0...v1.9.0) (2023-09-13)


### Features

* allow configuring torrent search category ([71cb07e](https://github.com/pikdum/plugin.video.haru/commit/71cb07e3e0ee2749fb816925ed32df77cef3329b))
* move clear history under settings ([3f97401](https://github.com/pikdum/plugin.video.haru/commit/3f97401f36a8b8e6ab5ab360ad2eeeccee7936da))
* **subsplease:** move all airing to bottom ([74a1847](https://github.com/pikdum/plugin.video.haru/commit/74a184743892ca695fa37028f87acd79e34b4005))
* sukebei support ([7201047](https://github.com/pikdum/plugin.video.haru/commit/7201047796ece182eba9f94c3ad621b046a2d643))
* **torrents:** allow choosing search category ([697fc8f](https://github.com/pikdum/plugin.video.haru/commit/697fc8faf719898a2a60e9d9d971a7ca475aed66))
* torrest support + addon settings ([#33](https://github.com/pikdum/plugin.video.haru/issues/33)) ([#36](https://github.com/pikdum/plugin.video.haru/issues/36)) ([cff0285](https://github.com/pikdum/plugin.video.haru/commit/cff02852ac8fe80e7917b993f9c6b0d160e629b1))


### Bug Fixes

* **subsplease:** remove tbd ([3d58059](https://github.com/pikdum/plugin.video.haru/commit/3d58059fa7adb0f5a8a35acd96601ac097666199))

## [1.8.0](https://github.com/pikdum/plugin.video.haru/compare/v1.7.0...v1.8.0) (2023-07-18)


### Features

* **subsplease:** thumbnail art ([e6f7e5f](https://github.com/pikdum/plugin.video.haru/commit/e6f7e5fa6f2127b1b7c82951b704534dd6a74f0f))


### Bug Fixes

* **subsplease:** broken history links ([55d46b3](https://github.com/pikdum/plugin.video.haru/commit/55d46b39441c9a7bd1ee0b686994b5d3376cee43))

## [1.7.0](https://github.com/pikdum/plugin.video.haru/compare/v1.6.0...v1.7.0) (2022-10-06)


### Features

* add somewhat working AnimeXin support ([#29](https://github.com/pikdum/plugin.video.haru/issues/29)) ([11ca456](https://github.com/pikdum/plugin.video.haru/commit/11ca45608059dd23c82abcc80b7ef3a53b85f532))

## [1.6.0](https://github.com/pikdum/plugin.video.haru/compare/v1.5.0...v1.6.0) (2022-08-13)


### Features

* **nyaa:** show more torrent details ([4c287ea](https://github.com/pikdum/plugin.video.haru/commit/4c287eaaf41eac5b62995b53f0a0810b7e1247be))
* **nyaa:** show torrent description ([d294839](https://github.com/pikdum/plugin.video.haru/commit/d294839c82ca567cf84df717f8d78a6688c058e1))
* **subsplease:** show anime description ([3309587](https://github.com/pikdum/plugin.video.haru/commit/33095879401eb0c6b8175ab0a08742e5c5d8a2c5))

## [1.5.0](https://github.com/pikdum/plugin.video.haru/compare/v1.4.2...v1.5.0) (2022-05-09)


### Features

* allow toggling reuselanguageinvoker ([0adecf0](https://github.com/pikdum/plugin.video.haru/commit/0adecf0624ceec2baa855a263f64228654681f2f))

### [1.4.2](https://github.com/pikdum/plugin.video.haru/compare/v1.4.1...v1.4.2) (2022-04-29)


### Bug Fixes

* file playback in torrent subfolder ([b3d1926](https://github.com/pikdum/plugin.video.haru/commit/b3d19265e3d4af227244b5a266a1766c9bc2ecf4))

### [1.4.1](https://github.com/pikdum/plugin.video.haru/compare/v1.4.0...v1.4.1) (2022-04-29)


### Bug Fixes

* remove news formatting; simplify logic ([c3a6569](https://github.com/pikdum/plugin.video.haru/commit/c3a656922396d7a48a1769b2de6299363d42378a))

## [1.4.0](https://github.com/pikdum/plugin.video.haru/compare/v1.3.1...v1.4.0) (2022-04-29)


### Features

* add confirmation dialog for clear history ([260912f](https://github.com/pikdum/plugin.video.haru/commit/260912f0b1d0eeec0d7811f85a98f5cac7685203))
* add nyaa torrent history ([6ea02a3](https://github.com/pikdum/plugin.video.haru/commit/6ea02a3b7cef69b9d0e9891ac32212cff771c3df))
* add nyaa torrent search ([d0e435f](https://github.com/pikdum/plugin.video.haru/commit/d0e435f8d4cbbeba695a5f6599605c9310cc7271))
* link to shows from history page ([770cb57](https://github.com/pikdum/plugin.video.haru/commit/770cb5742a34a4a2edaf3207ca0b87e60fa9a660))


### Bug Fixes

* better page name ([932b4ce](https://github.com/pikdum/plugin.video.haru/commit/932b4ce2d4d778938fa710ab6d7b82896d32510b))

### [1.3.1](https://github.com/pikdum/plugin.video.haru/compare/v1.3.0...v1.3.1) (2022-04-01)


### Bug Fixes

* check if exists before deleting key ([9085e3c](https://github.com/pikdum/plugin.video.haru/commit/9085e3cc706d74e969a9b0bb8154c0a060b7992e))

## [1.3.0](https://github.com/pikdum/plugin.video.haru/compare/v1.2.0...v1.3.0) (2022-03-31)


### Features

* cache art, show cached art in more views ([545887b](https://github.com/pikdum/plugin.video.haru/commit/545887b71a579a67bc38b08f24e139f67041dc37))


### Bug Fixes

* fix logging ([d2184d1](https://github.com/pikdum/plugin.video.haru/commit/d2184d15bcefc69ed7e386ae618f676e4745acf2))

## [1.2.0](https://github.com/pikdum/plugin.video.haru/compare/v1.1.3...v1.2.0) (2022-03-31)


### Features

* add subsplease watch history ([dd6ab81](https://github.com/pikdum/plugin.video.haru/commit/dd6ab81953155d465d28379ac4dd55a8743ee1b1))

### [1.1.3](https://github.com/pikdum/plugin.video.haru/compare/v1.1.2...v1.1.3) (2022-03-31)


### Bug Fixes

* use system time zone instead of hardcoding it ([49259d2](https://github.com/pikdum/plugin.video.haru/commit/49259d25197420a91d1c7d623a1c73c57c535151))

### [1.1.2](https://github.com/pikdum/plugin.video.haru/compare/v1.1.1...v1.1.2) (2022-03-24)


### Bug Fixes

* new fancy logo ([4c645d3](https://github.com/pikdum/plugin.video.haru/commit/4c645d359448db35ec612756c40b51d316d8e132))

### [1.1.1](https://github.com/pikdum/plugin.video.haru/compare/v1.1.0...v1.1.1) (2022-03-24)


### Bug Fixes

* change name to lowercase haru ([7dfe3e8](https://github.com/pikdum/plugin.video.haru/commit/7dfe3e834a7885bf32e68e65210144fa95160df1))

## [1.1.0](https://github.com/pikdum/plugin.video.haru/compare/v1.0.2...v1.1.0) (2022-03-24)


### Features

* better icon + fanart ([d58d078](https://github.com/pikdum/plugin.video.haru/commit/d58d0789703bdef8e6761811100faf9e70f0f873))

### [1.0.2](https://github.com/pikdum/plugin.video.haru/compare/v1.0.1...v1.0.2) (2022-03-06)


### Performance Improvements

* only call get_nyaa_magnet before playing ([2b6e007](https://github.com/pikdum/plugin.video.haru/commit/2b6e00733bc27c895b0ae445abe92f2af8606bf3))

### [1.0.1](https://github.com/pikdum/plugin.video.haru/compare/v1.0.0...v1.0.1) (2022-03-01)


### Bug Fixes

* pin resolveurl version ([7ead65f](https://github.com/pikdum/plugin.video.haru/commit/7ead65f82eefdb5776dfa3e4210d8fd7b9667b0a))

## 1.0.0 (2022-03-01)


### Features

* add an icon ([9dc7dac](https://github.com/pikdum/plugin.video.haru/commit/9dc7dac2904c60cb177aa62904aa8bf95f43bd22))
* basic subsplease.org support ([2b25a24](https://github.com/pikdum/plugin.video.haru/commit/2b25a247977f4399a4922531095f83f5b361e5b0))
* batch formatting + poster art + regex tweak ([bc275d2](https://github.com/pikdum/plugin.video.haru/commit/bc275d2f1e41efda7ccf80ba60c7a8673a434ccf))
* clean up batch display names ([9e29020](https://github.com/pikdum/plugin.video.haru/commit/9e29020c340002bdf26aaca3de5531dc22ab70ba))
* indicate watched shows ([3284d30](https://github.com/pikdum/plugin.video.haru/commit/3284d3041f48ded6d1665efc7828cc9e5a73b7ed))
* initial commit ([5be843f](https://github.com/pikdum/plugin.video.haru/commit/5be843fd6b4cd14ea2b705c5c5b2a73bfc4e2e14))
* persistent storage; watched indicators ([abe51df](https://github.com/pikdum/plugin.video.haru/commit/abe51df4f73789e721ae1dafbab67ea95f1f83b9))
* show air date + poster art ([4f50acf](https://github.com/pikdum/plugin.video.haru/commit/4f50acfa0af4651d4b0c66114f5bb4b45147bec1))
* show airing anime by day ([1def455](https://github.com/pikdum/plugin.video.haru/commit/1def45550cdf8c43b9555c411c5d0b238e192a5f))
* show all currently airing anime ([e4cf17d](https://github.com/pikdum/plugin.video.haru/commit/e4cf17da4698323a21fcd898bf15f5fa277a5a70))
* show release date; use color for watched ([6afbacc](https://github.com/pikdum/plugin.video.haru/commit/6afbacc7a620cc7961bc927996cd2097fcac2d6e))
* working batches with patched resolveurl ([e76709f](https://github.com/pikdum/plugin.video.haru/commit/e76709f64d5664eac7de4b63ad98e41de27910d2))


### Bug Fixes

* batch name highlighting ([9d0347c](https://github.com/pikdum/plugin.video.haru/commit/9d0347c75f0e400a61fb318162c8fce94185e671))
* ensure database has base keys ([6fb4371](https://github.com/pikdum/plugin.video.haru/commit/6fb4371acea14f29c73cd92350f6e20bf18717bc))
* fix watched sorting to top ([556b72f](https://github.com/pikdum/plugin.video.haru/commit/556b72f5dc5bfdf230bace268d278507ae1ec118))
